Welcome To EventZen!

The first you need to do to access the client site you must sign, if you don't have an account yet you can create one in the sign up button.

if you were to sign in as an admin, you must first use "kiel" as username, then "ponkan" as password to enter the admin site, then you can add your member account in the member management.


Going back to the client site, upon succesfully loging in, you will see the list of events, after clicking one of the events you will see descriptions about the event then the apply button
where you can set an appointment to meet with the chuech admin to further discuss your event inquiry.

the is also a button that will show the map of where the church is located so the users can find the location.

before the "about" section there is a comment section where the clients can leave a comment about their experience with the website which will appear dynamically.


Going to the admin side, the admin will select one of the events where they can register the clients desired event upon meeting in the church office.
After registering the event it will be saved in th databse and then the admin can put the registered event's name and date on the Upcoming events panel.